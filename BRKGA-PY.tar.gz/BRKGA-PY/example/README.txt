Plain driver: a sample driver and Decoder class that make use of the BRKGA API. 

To run the program, type:
	python api-usage.py
	
To modify any of the BRKGA parameters, edit the file api-usage.py.
